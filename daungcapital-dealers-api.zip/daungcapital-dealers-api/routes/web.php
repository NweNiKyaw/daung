<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/test', function () {
    return bcrypt(123456);
});
Route::get('/', function () {
    return redirect('/api-docs');
});

Route::get('/api', function () {
    return redirect('/api-docs');
});

Route::get('/api-docs', function () {
    $url = url('/documentation/openapi.yaml');
    return view('api_documentation', compact('url'));
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('/dealer')->group(function () {
        Route::get('/', 'DealerController');
    });

    Route::prefix('/dealer/invoices')->group(function () {
        Route::get('/', 'DealerInvoiceController@index');
        Route::get('/amount', 'DealerInvoiceController@amount');
    });

    Route::prefix('/dealer/tablets')->group(function () {
        Route::get('/', 'DealerTabletController@index');
        Route::post('/', 'DealerTabletController@store');
    });

    Route::prefix('/customers')->group(function () {
        Route::get('/meta', 'CustomerController@meta');
        Route::get('/find', 'CustomerController@find');
        Route::get('/', 'CustomerController@index');
        Route::post('/', 'CustomerController@store');
        Route::get('/{customer}', 'CustomerController@show');
        // Route::put('/{customer}', 'CustomerController@update');
        Route::delete('/{customer}', 'CustomerController@delete');
        Route::post('/files', 'CustomerFileController');
    });

    Route::prefix('/loans')->group(function () {
        Route::get('/approves/monthly', 'LoanApproveController@monthly');
        Route::get('/sales/monthly', 'LoanSaleController@monthly');
        Route::get('/meta', 'LoanController@meta');
        Route::get('/', 'LoanController@index');
        Route::post('/', 'LoanController@store');
        Route::get('/{loan}', 'LoanController@show');
        Route::post('/files', 'LoanFileController');
        Route::post('/submit', 'LoanSubmitController');
    });

    Route::prefix('/fingerprints')->group(function () {
        Route::post('/', 'FingerprintController@store');
    });

    Route::prefix('/invoices')->group(function () {
        Route::get('/meta', 'InvoiceController@meta');
        Route::get('/amount', 'InvoiceController@amount');
        Route::get('/', 'InvoiceController@index');
        Route::get('{invoices}', 'InvoiceController@show');
    });

    Route::prefix('/payments')->group(function () {
        Route::get('/', 'PaymentController@index');
        Route::post('/', 'PaymentController@store');
        Route::get('/{payment}', 'PaymentController@show');
    });

    Route::prefix('/ownerbooks')->group(function () {
        Route::get('/receives/monthly', 'OwnerBookReceiveController@monthly');
        Route::get('/meta', 'OwnerBookController@meta');
        Route::get('/', 'OwnerBookController@index');
        Route::get('/{ownerbooks}', 'OwnerBookController@show');
    });

    Route::prefix('/contracts')->group(function () {
        Route::get('/', 'ContractController@index');
        Route::get('/{contract}', 'ContractController@show');
    });

    Route::post('/files/temporary', 'TemporaryUploadController');

    Route::get('/settings', 'SettingController');

});

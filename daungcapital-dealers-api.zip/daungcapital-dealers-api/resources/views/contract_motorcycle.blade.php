<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cash Loan Contract</title>
    <style>
        @page {
            header: page-header;
        }

        body {
            font-family: Tharlon, sans-serif;
            font-size: 10px;
        }

        header {
            width: 100%;
        }

        p {
            text-align: justify;
        }

        .h1 {
            border-bottom: 1px solid #999;
            color: #323e99;
            font-size: 12px;
            padding: 30px 0 20px;
            text-align: center;
        }

        .h2 {
            font-size: 11px;
        }

        .h3 {
            font-size: 10px;
            padding: 20px 0 10px;
        }

        .company-logo {
            height: 60px;
        }

        .header .table, .footer .table, .invoice-meta-wrapper .table {
            border-collapse: collapse;
            width: 100%;
        }

        .invoice-meta-wrapper .table .table-row {
            border-width: 0;
        }

        .invoice-meta-wrapper .table .table-row .table-cell:first-child {
            padding: 0 15px 5px;
            text-align: right;
        }

        .table-items {
            margin-top: 30px;
            width: 100%;
        }

        .table-items tr th {
            padding: 15px 0;
        }

        .table-items tr td {
            padding: 5px 0;
        }

        .table-items tr:first-child th {
            border-bottom: 1px dotted #333;
        }

        .table-items tr:last-child td {
            border-bottom: 1px dotted #333;
        }

        .totals {
            text-align: right;
        }

        .table-items .table-body .table-row .table-header {
            color: #4c5357;
        }

        .status {
            font-size: 24px;
            font-weight: 400;
            position: absolute;
            top: 58%;
            left: 42%;
            padding: 10px 15px;
            border: 1px solid gold;28
            transform: rotate(-45deg);
            text-transform: uppercase;
            color: gold;
        }

        .loans {
            border-collapse: collapse;
            text-align: left;
            width: 100%;
            margin-bottom: 5px;
        }

        .loans th {
            background-color: lightgray;
        }

        .loans th, .loans td {
            border: 1px solid #000;
            padding: 8px;
        }

        .signers {
            width: 100%;
        }

        .prepared-by {
            margin-top: 30px;
        }

        .prepared-by td {
            padding: 6px 0 6px;
        }

        .fund {
            float: left;
            border-collapse: collapse;
            text-align: left;
            margin: 3px;
        }

        .fund th {
            background-color: lightgray;
        }

        .fund th, .fund td {
            border: 1px solid #000;
            padding: 8px;
        }

        .signature {
            color: #000;
            font-size: 52px;
        }
        
        a {
            color: blue;
        }
    </style>
</head>
<body>
    <htmlpageheader name="page-header">
        <div class="header">
            <table class="table">
                <tbody class="table-body">
                    <tr class="table-row">
                        <td style="text-align: left;">
                            <img class="company-logo" src="{{asset('images/invoice-header.png')}}">
                        </td>
                        <td style="text-align: right;">
                            <div>
                                <strong>Daung Capital Co., Ltd</strong>
                            </div>
                            <div>
                                <span>1260, Innwa Third Street, Quarter 6, South Okkalapa, Yangon</span>
                            </div>
                            <div>
                                <span>support@daungcapital.com</span>
                            </div>
                            <div>
                                <a>https://www.daungcapital.com</a>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </htmlpageheader>
    <main>
        <h1 style="text-align: center;">ငှားရမ်းဝယ်ယူခြင်းဆိုင်ရာသဘောတူစာချုပ်</h1>
        <h2>စာချုပ်အမှတ် {{$contract_number}}</h2>
        <p>
            ဤငှားရမ်းခြင်းဆိုင်ရာ သဘောတူစာချုပ် (ဤစာချုပ်ကို) {{$date}} တွင် အောက်ဖော်ပြပါ ပုဂ္ဂိုလ်များ အကြား သဘောတူ လက်မှတ် ရေးထိုး ချုပ်ဆို ကြပါသည်။
        </p>
        <ol>
            <li>
                Daung Capital Co., Ltd (ပိုင်ရှင်)၊ ကုမ္ပဏီမှတ်ပုံတင်အမှတ် 475FC/2017-2018(YGN)၊
                <div>
                    မှတ်ပုံတင်ထားသောရုံးတည်နေရာ ၁၂၆၀၊ အင်း၀(၃)လမ်း၊ (၆)ရပ်ကွက်၊ တောင်ဥက္ကလာပမြို့နယ်။
                </div>
            </li>
            <li>
                အမည် {{$borrower_name}} (ငှားရမ်းသူ)၊ မှတ်ပုံတင်အမှတ် {{$borrower_nrc}}၊
                <div>
                    နေရပ်လိပ်စာ {{$borrower_address}}။
                </div>
            </li>
            @if($has_guarantor)
                <li>
                    အမည် {{$guarantor_name}} (အာမခံသူ)၊​ မှတ်ပုံတင်အမှတ် {{$guarantor_nrc}}၊
                    <div>
                        နေရပ်လိပ်စာ {{$guarantor_address}}။
                    </div>
                </li>
            @endif
        </ol>
        <h3 class="h3" style="text-align: center; text-transform: uppercase;">
            အဆိုပြုတင်ပြထားသောချေးငွေယူခြင်းဆိုင်ရာသဘောတူစာချုပ်အရဘဏ္ဍာရေးဆိုင်ရာကတိကဝတ်များအကျဉ်းချုပ်
        </h3>
        <h4>ကုန်ပစ္စည်း</h4>
        <table class="table" style="border-collapse: collapse; table-border: 0;">
            <thead class="table-head">
                <tr class="table-row">
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">ပစ္စည်းအမျိုးအစားသတ်မှတ်ချက်</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">တံဆိပ်</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">မော်ဒယ်</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">အရောင်</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">ချဲဆီးနံပါတ်</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">အင်ဂျင်နံပါတ်</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">လိုင်စင်နံပါတ်</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$desc}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$brand}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$model}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$color}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$chassis}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$engine}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$license}}</td>
                </tr>
            </tbody>
        </table>
        <h4>Term</h4>
        <p>
            ပိုင်ရှင်က ငှားရမ်းသူကို ငှားရမ်းရန် သဘောတူညီပြီး ငှားရမ်းသူကလည်း ပိုင်ရှင်ထံမှ ငှားရမ်းရန် သဘောတူညီချက်အရ ကုန်ပစ္စည်းကို {{$start_date}} (စတင်ငှားရမ်းသည့်နေ့) တွင် စတင် ငှားရမ်းပြီး {{$end_date}} (ကုန်ဆုံးသည့်နေ့) တွင် ငှားရမ်းမှု ပြီးဆုံးပါသည်။
        </p>
        <h4>ပြန်လည်ပေးချေမှုအစီအစဉ်</h4>
        <table class="table" style="border-collapse: collapse; table-border: 0;">
            <tbody class="table->body">
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">၁။ ကုန်ပစ္စည်းတန်ဖိုး</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">
                        {{$price}}
                    </td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">၂။ စရံငွေ</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">
                        {{$deposit}}
                    </td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">၃။ ကုန်ပစ္စည်းအသားတင်တန်ဖိုး</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">{{$principal}}</td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">၄။ အတိုးပမာဏ (တစ်လ {{$interest_rate}}%)</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">{{$interest}}</td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">၅။ ပေးချေရမည့်စုစုပေါင်းပမာဏ</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">{{$total_payment}}</td>
                </tr>
            </tbody>
        </table>
        <h4>Monthly Payments</h4>
        <p>
            အဆိုပြု တင်ပြထားသော ငှားရမ်း သဘောတူစာချုပ်အရ လူကြီးမင်းမှ ပေးသွင်းသော အရစ်ကျငွေပေးချေမှုများမှာ လစဉ်ငှားရမ်းခ အရစ်ကျပေးချေမှု အဖြစ် မြန်မာကျပ်ငွေ {{$monthly_payment}} ဖြစ်ပါသည်။ (နောင် အရစ်ကျ ငွေပေးချေမှုများဟု ခေါ်ဆိုပါမည်။)
        </p>
        <h4>အပိုင်း (က) ငှားရမ်းမှုသဘောတူစာချုပ်ကို စောစီးစွာပေးသွင်းခြင်း</h4>
        <p>
            စောစီးစွာ ပေးသွင်းသည့်အပေါ် မူတည်၍ ပေးသွင်းရမည့် လက်ကျန်ငွေတွက်နည်း<br>
            <span style="font-size: 8px;">(စုစုပေါင်းပေးသွင်းရမည့် ငွေပမာဏ - လက်ရှိကာလအထိရရှိပြီး အရစ်ကျပေးဆပ်ငွေ) x (၁- စောစီးစွာပြန်လည်ပေးချေမှုအတွက် လျှော့ပေါ့ငွေ)</span>
        </p>
        <p>
            ဤတွင်
        </p>
        <ul>
            <li>
                စုစုပေါင်း ပေးသွင်းရမည့် ငွေပမာဏမှာ အထက်တွင် ဖော်ပြထားသည့် အမှတ်စဉ် (၅) ပါ ငွေပမာဏဖြစ်ပါသည်။
            </li>
            <li>
                လက်ရှိကာလအထိရရှိပြီး ပေးဆပ်ငွေမှာ ပိုင်ရှင်သို့ ချေးငှားသူက လစဉ်ပေးသွင်းသော အရစ်ကျငွေများ ဖြစ်ပါသည်။ (နောက်ကျပေးသွင်းသော ပေးချေမှုအတွက် အတိုး သို့မဟုတ် အဖိုးအခများမပါဝင်ပါ)
            </li>
            <li>
                စောစီးစွာ ပြန်လည်ပေးချေမှုအတွက် လျှော့ပေါ့ငွေသည် ၅% သို့မဟုတ် ပိုင်ရှင်မှ အခါအားလျော်စွာ သတ်မှတ်သည့် ပမာဏဖြစ်ပါသည်။
            </li>
        </ul>
        <p>
            ပိုင်ရှင်သည် မည်သည့်အချိန်၌မဆို ငှားရမ်းသူအား ရက် (၃ဝ) ကြိုတင်၍ နို့တစ်စာပေးပို့လျှက် <strong>စောစီးစွာ ပြန်လည်ပေးချေမှုအတွက် လျှော့ပေါ့ငွေ</strong> အား ပြင်ဆင်နိုင်သည်။ စောစီးစွာ ပြန်လည်ပေးချေမှုအတွက် သင်၏ စရန်ငွေအား ပြန်အမ်းမည် မဟုတ်ပါ။
        </p>
        <h4>အပိုင်း (ခ) ရက်လွန်နောက်ကျသည့် အရစ်ကျငွေပေးချေမှုများအတွက် အတိုး</h4>
        <p>
            အကယ်၍ သင်၏ လစဉ်အရစ်ကျ ပေးချေငွေများကို လတစ်လ၏ရုံးဖွင့်ရက် (၃)* ရက်အတွင်း ကျွနု်ပ်တို့ လက်ခံရရှိခြင်း မရှိပါက ရက်လွန်ကြေးအတိုးငွေကို <strong>တနေ့လျှင် ဝ.၈ %</strong> ကောက်ခံသွားပါမည် (သို့မဟုတ်) ချေးငွေပေးသူမှ အခါအားလျော်စွာ သတ်မှတ်သည့် ယင်းကဲ့သို့သော အခြားငွေပမာဏ (သို့မဟုတ်) အခြား ရက်လွန်ကြေး အတိုးနှုန်းထားကို ကောက်ခံသွားပါမည်။
        </p>
        <p>
            ချေးငွေပေးသူသည် မည်သည့်အချိန်၌မဆို ချေးငွေယူသူအား ရက် (၃ဝ) ကြိုတင်၍ သတိပေးစာပေးပို့လျှက် ရက်လွန်ကြေးအတိုးကို တိုးမြှင့်နိုင်သည်။
        </p>
        <h3>ငှားရမ်းသူများအားအသိပေးခြင်း</h3>
        <p>
            ဤသဘောတူ စာချုပ်ပါ အချက်များအရ ငှားရမ်းသူနှင့် ပိုင်ရှင်တို့သည် ဤတွင်အောက်ပါအတိုင်း သဘောတူညီကြပါသည်။
        </p>
        <p>
            ငှားရမ်းသူသည် ကုန်ပစ္စည်းနှင့် ဆက်စပ်အစိတ်အပိုင်းများအားလုံးကို ကောင်းမွန်သည့် အခြေအနေင့် ပြုပြင်၍ အသုံးပြုနိုင်သည့် အနေအထားဖြစ်အောင် ပြုပြင်ထိန်းသိမ်း ထားရှိရမည်။ ပျောက်ဆုံးသွားသော၊ ထိခိုက်သွားသော သို့မဟုတ် ကျိုးပဲ့သွားသော အစိတ်အပိုင်းများကို တန်ဖိုးတူ၊ အရည်အသွေးတူသည့် တစ်ကုမ္ပဏီတည်းမှ ထုတ်လုပ်သော အစိတ်အပိုင်းများဖြင့် အစားထိုးထည့်သွင်းပေးရမည့်အပြင် ကာလညောင်း၍ ယိုယွင်းမှုနှင့် ဥပဒေအရ ပြစ်ဒဏ်အဖြစ် သိမ်းယူခံရခြင်း အပါအဝင် မည်သည့်နည်းလမ်းဖြင့်မဆို သို့မဟုတ် မည်သူ့ကြောင့်မဆို သို့မဟုတ် မည်သည့်အကြောင်းကြောင့်မဆို ကုန်ပစ္စည်းတွင်လည်းကောင်း သို့မဟုတ် အစိတ်အပိုင်းများတွင် လည်းကောင်း ဖြစ်ပေါ်လာသော ဆုံးရှုံးမှု သို့မဟုတ် ပျက်စီးမှု သို့မဟုတ် ထိခိုက်မှု တို့အတွက် ငှားရမ်းသူတစ်ဦးတည်းတွင်သာ တာဝန်ရှိသည်။
        </p>
        <h3>အသိပေးကြေညာခြင်းနှင့်သဘောတူညီခြင်း</h3>
        <p>
            လွဲမှားကောက်ယူခြင်း မရှိစေရန် အလို့ငှာ ချေးငွေယူသူ နှင့် ထောက်ခံသူ တို့သည် ဤစာချုပ်အား ဖတ်ရှုပြီးနားလည်သဘောပေါက်ပါကြောင်း ၊ စည်းကမ်းချက်များအတိုင်း လိုက်နာဆောင်ရွက်မည် ဖြစ်ကြောင်း တရားဝင် အသိပေးကြေငြာအပ်ပါသည်။
        </p>
        <p>
            အောက်ပါ သက်သေများရှေ့တွင် စာချုပ်ဝင်တို့သည် ဤစာချုပ်အား အထက်တွင်ဖော်ပြထားသည့် နေ့ရက်နှင့် ခုနှစ်တွင် လက်မှတ်ရေးထိုးကြသည်။
        </p>
        <h1 style="text-align: center;">RENTAL PURCHASE AGREEMENT</h1>
        <h2>Agreement #:{{$contract_number}}</h2>
        <p>
            This Rental Agreement ("this Agreement") is made on {{$date}} between
        </p>
        <ol>
            <li>
                Daung Capital Co., Ltd hereinafter referred to as the "Owner", a company incorporated in Myanmar (475FC/2017-2018(YGN)) having its registered office at 1260, Innwa Street, Quarter 6, South Okkalapa, Yangon, Myanmar
            </li>
            <li>
                {{$borrower_name}}, ({{$borrower_nrc}}) hereinafter referred to as the "Renter" of {{$borrower_address}}
            </li>
            @if($has_guarantor)
                <li>
                    အမည်  (အာမခံသူ)၊​ မှတ်ပုံတင်အမှတ် ၊
                    <div>
                        နေရပ်လိပ်စာ ။
                    </div>
                    {{$guarantor_name}}, ({{$guarantor_nrc}}) hereinafter referred to as the "Guarantor" of {{$guarantor_address}}
                </li>
            @endif
        </ol>
        <h3 class="h3" style="text-align: center; text-transform: uppercase;">
            SUMMARY OF FINANCIAL OBLIGATIONS UNDER PROPOSED RENTAL AGREEMENT
        </h3>
        <h4>GOODS</h4>
        <table class="table" style="border-collapse: collapse; table-border: 0;">
            <thead class="table-head">
                <tr class="table-row">
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">DESCRIPTION OF GOODS</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">Brand</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">Model</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">Colour</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">Chassis Number</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">Engine Number</th>
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">License Number</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$desc}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$brand}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$model}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$color}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$chassis}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$engine}}</td>
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">{{$license}}</td>
                </tr>
            </tbody>
        </table>
        <h4>Term</h4>
        <p>
            The Owner agrees to lease to the Renter, and the Renter agrees to lease from the Owner, the Goods for a term beginning on {{$start_date}} ("Commencement Date") and ending on {{$end_date}} ("Term").
        </p>
        <h4>REPAYMENT SCHEDULE</h4>
        <table class="table" style="border-collapse: collapse; table-border: 0;">
            <tbody class="table->body">
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">1) Price of Goods</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">
                        {{$price}}
                    </td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">2) Cash deposit</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">
                        {{$deposit}}
                    </td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">3) Net Price of Goods</td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">{{$principal}}</td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        4) Total commitment charges at {{$interest_rate}}% per month
                    </td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">
                        {{$interest}}
                    </td>
                </tr>
                <tr class="table-row">
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        5) Total Amount Payable
                    </td>
                    <td style="border: 1px solid #000; padding: 8px; text-align: right; vertical-align: top;">
                        {{$total_payment}}
                    </td>
                </tr>
            </tbody>
        </table>
        <h4>Monthly Payments</h4>
        <p>
            Your instalments under the proposed agreement will be monthly rental instalments of MMK {{$monthly_payment}} (hereinafter called the “Instalments”).
        </p>
        <h4>Section A: Early settlement of loan</h4>
        <p>
            The method for calculating the balance payable upon early settlement is:<br>
            <span style="font-size: 8px;">(Total Amount Payable – Instalments Received To Date) x (1 – Early Repayment Discount)</span>
        </p>
        <p>
            where:
        </p>
        <ul>
            <li>
                "Total Amount Payable" is the amount specified in Item 5 above
            </li>
            <li>
                "Instalments Received To Date" is the total amount of the aggregate amount of Instalments paid by the Renter to the Owner (exclusive of any late payment interest or fees)
            </li>
            <li>
                "Early Repayment Discount" is 5% or such other amount as the Owner may determine from time to time. 
            </li>
        </ul>
        <p>
            The Owner may at any time amend the <strong>Early Repayment Discount</strong> on giving the Renter 30 days' notice. Please note that your deposit will not be refunded in the event of an early settlement of the rental agreement.
        </p>
        <h4>Section B: Interest on overdue Instalments</h4>
        <p>
            If we do not receive your monthly instalment within 3 business days, the overdue interest charged will be <strong>0.8% per day</strong> or such other amount or such other rate of overdue interest as the Owner may determine from time to time.
        </p>
        <p>
            The Owner may at any time increase the overdue interest charged upon giving the Renter 30 days' notice.
        </p>
        <h3>NOTICE TO RENTERS</h3>
        <p>
            Under the provisions of this Agreement, the Renter hereby agrees with the Owner as follows:
        </p>
        <p>
            To keep and maintain the Goods and all parts thereof in good and serviceable repair and condition and to replace all missing, damaged or broken parts of the Goods by parts of the same make, equal value and quality and to be solely responsible for any loss or destruction of or for any damage to the Goods or any part thereof occasioned in any manner or by whomsoever or by any cause whatsoever, including fair wear and tear and lawful forfeiture.
        </p>
        <h3>DECLARATION AND AGREEMENT</h3>
        <p>
            For the avoidance of doubt, the Renter and Guarantor hereby declare and agree that they have read and understood the Agreement agree to be bound by our General Terms and Conditions (see http://www.daungcapital.com/tnc). The General Terms and Conditions form an integral part of this Agreement, and the defined term in this Agreement apply to the General Terms and Conditions, and vice versa, unless the context clearly indicates otherwise.
        </p>
        <p>
            IN WITNESS WHEREOF the parties hereto have respectively set their hands the day and year first above written.
        </p>
        <table style="border: 1px solid #000; border-spacing: 0; border-collapse: collapse; max-width: 100%; width: 100%;">
            <thead>
            <tr>
                <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">
                    ငှားရမ်းသူ Renter
                </th>
                @if($has_guarantor)
                    <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">
                        အာမခံသူ Guarantor
                    </th>
                @endif
                <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">
                    Dealer
                </th>
                <th style="background-color: #e5e5e5; border: 1px solid #000; padding: 8px; vertical-align: top;">
                    Daung Capital Co., Ltd
                </th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    အမည် Name<br />{{$borrower_name}}
                </td>
                @if($has_guarantor)
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        အမည် Name<br />{{$guarantor_name}}
                    </td>
                @endif
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    အမည် Name<br />{{$dealer_name}}
                </td>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    အမည် Name<br /><span style="color: #fff;">[[t|3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;]]</span>
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    မှတ်ပုံတင်အမှတ် NRC Number<br />{{$borrower_nrc}}
                </td>
                @if($has_guarantor)
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        မှတ်ပုံတင်အမှတ် NRC Number<br />{{$guarantor_nrc}}
                    </td>
                @endif
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    NRC Number မှတ်ပုံတင်အမှတ်<br />{{$dealer_nrc}}
                </td>
                <td rowspan="3" style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    ရာထူး Designation<br /><span style="color: #fff;">[[t|3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;]]</span>
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    မိုဘိုင်းဖုန်းနံပါတ် Phone Number<br />{{$borrower_phone}}
                </td>
                @if($has_guarantor)
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        မိုဘိုင်းဖုန်းနံပါတ် Phone Number<br />{{$guarantor_phone}}
                    </td>
                @endif
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    မိုဘိုင်းဖုန်းနံပါတ် Phone Number<br />{{$dealer_phone}}
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    အီးမေး Email Address<br />{{$borrower_email}}
                </td>
                @if($has_guarantor)
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        အီးမေး Email Address<br />{{$guarantor_email}}
                    </td>
                @endif
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    အီးမေး Email Address<br />{{$dealer_email}}
                </td>
            </tr>
            <tr>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    လက်မှတ် Signature<br /><span style="font-size: 52px; color: #fff;">[[s|1]]</span>
                </td>
                @if($has_guarantor)
                    <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                        လက်မှတ် Signature<br /><span style="font-size: 52px; color: #fff;">[[s|2]]</span>
                    </td>
                @endif
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    လက်မှတ် Signature<br /><span style="font-size: 52px; color: #fff;">[[s|0]]</span>
                </td>
                <td style="border: 1px solid #000; padding: 8px; vertical-align: top;">
                    လက်မှတ် Signature<br /><span style="font-size: 52px; color: #fff;">[[s|3]]</span>
                </td>
            </tr>
            </tbody>
        </table>
    </main>
</body>
</html>
<?php

return [
    'token'     => env('SIGN_REQEUEST_TOKEN'),
    'subdomain' => env('SIGN_REQEUEST_SUBDOMAIN'),
];

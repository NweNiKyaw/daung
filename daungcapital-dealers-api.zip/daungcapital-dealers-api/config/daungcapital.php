<?php

return [
    /**
     * CURRENCY CODE & SYMBOL
     */
    'currency' => [
        'code' => 'MMK',
        'symbol' => 'ကျပ်'
    ],

    /**
     * POSITION FOR THE DECIMALS
     *
     * Specify the scale the decimal should be accurate to.
     * The system accepts up to 2.
     */
    'decimal' => [
        'scale' => 0
    ],

    'invoice' => [
        'generate_on' => 16
    ],

    'signrequest' => [
        'sender' => env('SIGNREQUEST_SENDER', 'thomascastle.dvlp@gmail.com'),
        'from' => env('SIGNREQUEST_FROM', 'thomascastle.dvlp@gmail.com'),
        'to' => env('SIGNREQUEST_TO', 'toelintun@daungcapital.com'),
    ]
];

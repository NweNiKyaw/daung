<?php

namespace App\Http\Controllers;

use App\DaungCapital\Helper;
use App\Models\Loan;
use App\Models\OwnerBook;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoanApproveController extends Controller
{
    public function monthly(Request $request)
    {
        $request->validate([
            'start_year' => 'required',
            'start_month' => 'required',
            'end_year' => 'required',
            'end_month' => 'required',
        ]);

        $start_date = Helper::firstDayOfMonth($request->start_year, $request->start_month);
        $end_date = Helper::lastDayOfMonth($request->end_year, $request->end_month);

        $loanTable = (new Loan());
        $ownerBookTable = (new OwnerBook);

        $data = $request->user()
                        ->loans()
                        ->selectRaw(DB::raw('count(*) as approved_count'))
                        ->selectRaw(DB::raw("(SELECT COUNT(*) FROM {$ownerBookTable->getTable()} WHERE loan_id = loans.{$loanTable->getKeyName()} AND received_at IS NOT NULL) as received_ownerbook_count"))
                        ->selectRaw(DB::raw('YEAR(`loans`.`approved_at`) as year'))
                        ->selectRaw(DB::raw('MONTH(`loans`.`approved_at`) as month'))
                        ->whereBetween('loans.approved_at', [$start_date, $end_date])
                        ->groupBy('year')
                        ->groupBy('month')
                        ->groupBy('laravel_through_key') // laravel need every select columns in group, known as ONLY_FULL_GROUP_BY
                        ->groupBy('received_ownerbook_count') // laravel need every select columns in group, known as ONLY_FULL_GROUP_BY
                        ->get()
                        ->makeHidden(['start_date', 'end_date', 'laravel_through_key']);

        return [
            'data' => $data,
            'total' => count($data)
        ];
    }
}

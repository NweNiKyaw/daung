<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LoanSubmitController extends Controller
{
    public function __invoke(Request $request)
    {
        $request->validate([
            'loan_id' => [
                'required',
                'integer',
                Rule::exists('loans', 'id')->whereIn(
                    'borrower_id',
                    $request->user()
                            ->customers()
                            ->pluck((new Customer)->getKeyName())
                            ->toArray()
                )
            ]
        ]);

        $loan = $request->user()->loans()->find($request->loan_id);
        $loan->status = "submitted";
        $loan->submitted_at = Carbon::now();
        $loan->submitted_by = $request->user()->getKey();
        $loan->save();

        return $loan;
    }
}

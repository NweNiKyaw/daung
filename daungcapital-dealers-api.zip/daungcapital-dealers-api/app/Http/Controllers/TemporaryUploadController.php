<?php

namespace App\Http\Controllers;

use App\DaungCapital\OCR;
use App\Models\TemporaryUpload;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TemporaryUploadController extends Controller
{
    public function __invoke(Request $request)
    {
        $request->validate([
            'type' => 'in:nrc',
            'file' => 'required|file',
            'name' => Rule::requiredIf($request->type !== 'nrc')
        ]);

        $temporaryUpload = TemporaryUpload::create();

        if ($request->type === 'nrc') {
            return $this->processNRCFile($temporaryUpload);
        }

        $temporaryUpload->addMedia(request()->file('file'))
                          ->usingName($request->name)
                          ->toMediaCollection();

        $temporaryUpload->load('media');

        return response([
            'temporary_upload_id' => $temporaryUpload->id,
            'full_url' => $temporaryUpload->media[0]['full_url'],
            'name' => $temporaryUpload->media[0]['name']
        ], 201);
    }

    private function processNRCFile($temporaryUpload)
    {
        $path = request()->file('file')->store('tmp');

        $ocr = new OCR();
        if ($data = $ocr->ocrMyanmarIDCard($path)) {
            $temporaryUpload->addMedia(request()->file('file'))
                                 ->usingName('nrc_' . $data['side'])
                                 ->toMediaCollection();

            $data['imgUrl'] = $temporaryUpload->getFirstMediaUrl();
            $data['temporary_upload_id'] = $temporaryUpload->id;

            return response()->json($data, 201);
        };

        return $this->unprocessableEntityResponse([
            'file' => ['The file is not a valid NRC.'],
        ]);
    }
}

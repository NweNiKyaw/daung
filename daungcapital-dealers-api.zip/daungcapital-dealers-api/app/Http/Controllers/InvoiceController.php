<?php

namespace App\Http\Controllers;

use App\Filters\InvoiceFilter;
use App\Partials\InvoicePartial;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    private $invoicePartial;
    private $invoiceFilter;

    public function __construct(InvoicePartial $invoicePartial, InvoiceFilter $invoiceFilter)
    {
        $this->invoicePartial = $invoicePartial;
        $this->invoiceFilter = $invoiceFilter;
    }

    public function index(Request $request)
    {
        return $request->user()
                       ->invoices()
                       ->partial($this->invoicePartial)
                       ->filter($this->invoiceFilter)
                       ->paginate();
    }

    public function show(Request $request, $id)
    {
        return $request->user()
                       ->invoices()
                       ->partial($this->invoicePartial)
                       ->findOrFail($id);
    }

    public function meta(Request $request)
    {
        $user = $request->user();

        return [
            'paid_count' => $user->invoices()->filter($this->invoiceFilter)->status('paid')->count(),
            'partial_count' => $user->invoices()->filter($this->invoiceFilter)->status('partial')->count(),
            'unpaid_count' => $user->invoices()->filter($this->invoiceFilter)->status('unpaid')->count(),
            'overdue_count' => $user->invoices()->filter($this->invoiceFilter)->status('overdue')->count(),
        ];
    }

    public function amount(Request $request)
    {
        $user = $request->user();

        return [
            'total_amount' => $user->invoices()->filter($this->invoiceFilter)->sum('amount'),
            'total_paid_amount' => $user->invoices()->filter($this->invoiceFilter)->sum('paid_sum'),
        ];
    }
}

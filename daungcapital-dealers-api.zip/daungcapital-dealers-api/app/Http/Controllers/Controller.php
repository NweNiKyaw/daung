<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected function deleteResponse($boolean = true)
    {
        return response('', 204);
    }

    protected function forbiddenResponse($message)
    {
        return response([
            'message' => $message
        ], 403);
    }

    protected function unprocessableEntityResponse($errors, $message = 'The given data was invalid.')
    {
        return response([
            'message' => $message,
            'errors' => $errors
        ], 403);
    }
}

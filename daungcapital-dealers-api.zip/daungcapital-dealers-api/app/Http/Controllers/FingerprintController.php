<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class FingerprintController extends Controller
{
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'file' => 'required',
            'ansi' => 'required',
            'iso' => 'required',
            'customer_id' => [
                'required',
                'integer',
                Rule::exists('customers', '_id')->where('user_id', $request->user()->getKey())
            ],
        ]);

        $customer = $request->user()->customers()->find($request->customer_id);

        $fingerprint = $customer->fingerprint()->create($validatedData);

        $fingerprint->addMedia($request->file('file'))
                    ->usingName('fingerprint')
                    ->toMediaCollection();

        return $fingerprint;
    }
}

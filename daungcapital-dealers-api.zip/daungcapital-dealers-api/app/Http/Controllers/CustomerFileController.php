<?php

namespace App\Http\Controllers;

use App\DaungCapital\Helper;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Rabbit;

class CustomerFileController extends Controller
{
    private $getAllURL = 'https://uatpremium.getall.asia';

    public function __invoke(Request $request)
    {
        $request->validate([
            'customer_id' => [
                'required',
                'integer',
                Rule::exists('customers', '_id')->where('user_id', $request->user()->getKey())
            ],
            'type' => 'in:nrc',
            'file' => 'required|file',
            'name' => Rule::requiredIf($request->type !== 'nrc')
        ]);

        $customer = $request->user()
                            ->customers()
                            ->find($request->customer_id);

        if ($request->type === 'nrc') {
            $path = $request->file('file')->store('tmp');
            if ($response = $this->processNRCFile($path)) {
                $unicodeData = $this->zawgyiToUni(json_decode($response->getBody(), 1));

                $data = $this->transform($unicodeData);

                $customer->addMedia(request()->file('file'))
                         ->usingName('nrc_' . $data['side'])
                         ->toMediaCollection();

                return response()->json($data, 201);
            };

            return $this->unprocessableEntityResponse([
                'file' => ['The file is not a valid NRC.'],
            ]);
        }

        $media = $customer->addMedia(request()->file('file'))
                          ->usingName($request->name)
                          ->toMediaCollection();

        return response($media, 201);
    }

    private function fetch($params)
    {
        return (new Client([
            'base_uri' => $this->getAllURL
        ]))->request(
            $params['method'],
            $params['url'],
            $params['data']
        );
    }

    private function processNRCFile($path)
    {
        try {
            $response = $this->fetch([
                'method' => 'POST',
                'url' => 'uploads',
                'data' => [
                    'multipart' => [
                        [
                            'name' => 'avatar',
                            'contents' => fopen(Storage::path($path), 'r')
                        ],
                        [
                            'name' => 'nrc',
                            'contents' => true
                        ],
                    ],
                ]
            ]);
        } catch (\Exception $e) {
            Log::error("[{$e->getCode()}] {$e->getMessage()}");

            return false;
        } finally {
            Storage::delete($path);
        }

        return $response;
    }

    private function zawgyiToUni($data)
    {
        return array_map(function ($item) {
            return Rabbit::zg2uni($item) ;
        }, $data);
    }

    private function transform($data)
    {
        $result = [];
        foreach ($data as $key => $value) {
            switch ($key) {
                case 'birth':
                    $result[$key] = Helper::burmeseNumericToEnglish($value);
                    break;
                default:
                    $result[$key] = $value;
                    break;
                }
        }

        return $result;
    }
}

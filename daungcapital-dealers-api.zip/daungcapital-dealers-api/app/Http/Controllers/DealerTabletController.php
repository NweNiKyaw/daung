<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DealerTabletController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()->tablets()->paginate();
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'device_id' => 'required',
            'push_token' => 'required',
        ]);

        return $request->user()->tablets()->updateOrCreate(
            ['device_id' => $validatedData['device_id']],
            $validatedData
        );
    }
}

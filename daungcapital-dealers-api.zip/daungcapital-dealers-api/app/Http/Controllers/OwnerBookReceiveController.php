<?php

namespace App\Http\Controllers;

use App\DaungCapital\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OwnerBookReceiveController extends Controller
{
    public function monthly(Request $request)
    {
        $request->validate([
            'start_year' => 'required',
            'start_month' => 'required',
            'end_year' => 'required',
            'end_month' => 'required',
        ]);

        $start_date = Helper::firstDayOfMonth($request->start_year, $request->start_month);
        $end_date = Helper::lastDayOfMonth($request->end_year, $request->end_month);

        $data = $request->user()
                        ->ownerbooks()
                        ->selectRaw(DB::raw('count(*) as count'))
                        ->selectRaw(DB::raw('YEAR(`received_at`) as year'))
                        ->selectRaw(DB::raw('MONTH(`received_at`) as month'))
                        ->whereBetween('received_at', [$start_date, $end_date])
                        ->groupBy('year')
                        ->groupBy('month')
                        ->groupBy('laravel_through_key') // laravel need every select columns in group, known as ONLY_FULL_GROUP_BY
                        ->get()
                        ->makeHidden(['laravel_through_key']);

        return [
            'data' => $data,
            'total' => count($data)
        ];
    }
}

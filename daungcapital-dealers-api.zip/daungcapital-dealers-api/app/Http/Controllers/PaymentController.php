<?php

namespace App\Http\Controllers;

use App\Filters\PaymentFilter;
use App\Models\Invoice;
use App\Models\Loan;
use App\Models\Payment;
use App\Partials\PaymentPartial;
use App\Scopes\InvoiceStatusScope;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PaymentController extends Controller
{
    private $loan;
    private $invoice;
    private $payment;
    private $paymentPartial;
    private $paymentFilter;

    public function __construct(
        Loan $loan,
        Invoice $invoice,
        Payment $payment,
        PaymentPartial $paymentPartial,
        PaymentFilter $paymentFilter
    ) {
        $this->loan = $loan;
        $this->invoice = $invoice;
        $this->payment = $payment;
        $this->paymentPartial = $paymentPartial;
        $this->paymentFilter = $paymentFilter;
    }

    public function index(Request $request)
    {
        $request->validate([
            'invoice_id' => [
                'required',
                Rule::exists($this->invoice->getTable(), $this->invoice->getKeyName())
                ->whereIn(
                    'loan_id',
                    $request->user()
                            ->loans()
                            ->pluck($this->loan->getKeyName())
                            ->toArray()
                ),
            ]
        ]);

        return $this->invoice
                    ->withoutGlobalScope(InvoiceStatusScope::class)
                    ->find($request->invoice_id)
                    ->payments()
                    ->partial($this->paymentPartial)
                    ->filter($this->paymentFilter)
                    ->paginate();
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'invoice_id' => [
                'required',
                Rule::exists($this->invoice->getTable(), $this->invoice->getKeyName())
                ->whereIn(
                    'loan_id',
                    $request->user()
                            ->loans()
                            ->pluck($this->loan->getKeyName())
                            ->toArray()
                ),
            ],
            'collection_date' => 'required',
            'amount' => 'required'
        ]);

        return $this->invoice
                    ->withoutGlobalScope(InvoiceStatusScope::class)
                    ->find($request->invoice_id)
                    ->payments()
                    ->create($validatedData);
    }

    public function show($id, Request $request)
    {
        return $this->payment->whereIn(
            'invoice_id',
            $request->user()
                    ->invoices()
                    ->withoutGlobalScope(InvoiceStatusScope::class)
                    ->pluck("{$this->invoice->getTable()}.{$this->invoice->getKeyName()}")
                    ->toArray()
        )->findOrFail($id);
    }
}

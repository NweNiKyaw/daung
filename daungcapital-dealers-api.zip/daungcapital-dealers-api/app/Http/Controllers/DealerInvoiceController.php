<?php

namespace App\Http\Controllers;

use App\Filters\DealerInvoiceFilter;
use Illuminate\Http\Request;

class DealerInvoiceController extends Controller
{
    private $dealerInvoiceFilter;

    public function __construct(DealerInvoiceFilter $dealerInvoiceFilter)
    {
        $this->dealerInvoiceFilter = $dealerInvoiceFilter;
    }

    public function index(Request $request)
    {
        return $request->user()
                       ->dealerInvoices()
                       ->filter($this->dealerInvoiceFilter)
                       ->paginate();
    }

    public function amount(Request $request)
    {
        $user = $request->user();

        return [
            'total_amount' => $user->dealerInvoices()->filter($this->dealerInvoiceFilter)->sum('amount'),
            'paid_amount' => $user->dealerInvoices()->whereStatus('paid')->filter($this->dealerInvoiceFilter)->sum('amount'),
            'unpaid_amount' => $user->dealerInvoices()->whereStatus('unpaid')->filter($this->dealerInvoiceFilter)->sum('amount'),
        ];
    }
}

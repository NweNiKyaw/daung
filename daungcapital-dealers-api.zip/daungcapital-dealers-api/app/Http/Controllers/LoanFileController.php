<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LoanFileController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $request->validate([
            'loan_id' => [
                'required',
                'integer',
                Rule::exists('loans', 'id')->whereIn(
                    'borrower_id',
                    $request->user()
                            ->customers()
                            ->pluck((new Customer)->getKeyName())
                            ->toArray()
                )
            ],
            'file' => 'required|file',
            'name' => 'required'
        ]);

        $loan = $request->user()
                        ->loans()
                        ->find($request->loan_id);

        $media = $loan->addMedia($request->file('file'))
                      ->usingName($request->name)
                      ->toMediaCollection();

        return response($media, 201);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContractController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()
                       ->contracts()
                       ->paginate();
    }

    public function show(Request $request, $id)
    {
        return $request->user()
                       ->contracts()
                       ->findOrFail($id)
                       ->setAppends(['signers']);
    }
}

<?php

namespace App\Http\Controllers;

use App\DaungCapital\Setting;
use App\Filters\LoanFilter;
use App\Http\Requests\StoreLoan;
use App\Models\Loan;
use App\Models\TemporaryUpload;
use App\Partials\LoanPartial;
use Carbon\Carbon;
use Illuminate\Http\Request;

class LoanController extends Controller
{
    private $loanPartial;
    private $loanFilter;

    public function __construct(LoanPartial $loanPartial, LoanFilter $loanFilter)
    {
        $this->loanPartial = $loanPartial;
        $this->loanFilter = $loanFilter;
    }

    public function index(Request $request)
    {
        return $request->user()
                       ->loans()
                       ->partial($this->loanPartial)
                       ->filter($this->loanFilter)
                       ->order()
                       ->paginate();
    }

    public function store(StoreLoan $request, Setting $setting)
    {
        $loan = $request->user()->loans()->create(array_merge(
            $request->validated(),
            [
                'interest_rate' => $setting['package_' . $request->package . '_rental_rate'],
                'loan_duration' => $setting['package_' . $request->package . '_rental_tenure'],
                'admin_fee' => $setting['admin_fee_' . $request->item['type']],
                'submitted_at' => Carbon::now(),
                'submitted_by' => $request->user()->getKey()
            ]
        ));

        $this->attachMedia($loan, $request);

        $loan->item()->create($request->validated()['item']);

        if ($request->filled('fingerprint')) {
            $this->createFingerprint($loan, $request);
        }

        $loan->load('item');

        return $loan;
    }

    public function show(Request $request, $id)
    {
        return $request->user()
                       ->loans()
                       ->partial($this->loanPartial)
                       ->findOrFail($id);
    }

    public function meta(Request $request)
    {
        $user = $request->user();

        return [
            'total_count' => $user->loans()->count(),
            'pending_count' => $user->loans()->where('loans.status', 'pending')->count(),
            'submitted_count' => $user->loans()->where('loans.status', 'submitted')->count(),
            'checked_count' => $user->loans()->where('loans.status', 'checked')->count(),
            'approved_count' => $user->loans()->where('loans.status', 'approved')->count(),
            'reviewed_count' => $user->loans()->where('loans.status', 'reviewed')->count(),
            'disbursed_count' => $user->loans()->where('loans.status', 'disbursed')->count(),
            'declined_count' => $user->loans()->where('loans.status', 'declined')->count(),
            'withdrawn_count' => $user->loans()->where('loans.status', 'withdrawn')->count(),
            'writtenoff_count' => $user->loans()->where('loans.status', 'writtenoff')->count(),
            'closed_count' => $user->loans()->where('loans.status', 'closed')->count(),
            'complete_count' => $user->loans()->where('loans.status', 'complete')->count(),
        ];
    }

    private function createFingerprint(Loan $loan, Request $request)
    {
        $fingerprint = $loan->fingerprint()->create($request->fingerprint);

        $temp = (new TemporaryUpload())->find($request->fingerprint['temporary_upload_id']);

        $media = $temp->getMedia()->first();
        $media->move($fingerprint);
        $temp->delete();

        return $fingerprint;
    }

    private function attachMedia(Loan $loan, Request $request)
    {
        if ($request->filled('temporary_upload_ids')) {
            $temps = (new TemporaryUpload())->whereIn('id', $request->temporary_upload_ids)->get();

            $temps->map(function ($temp) use ($loan) {
                $temp->getMedia()->map(function ($media) use ($loan) {
                    $media->move($loan);
                });
                $temp->delete();
            });
        }
    }
}

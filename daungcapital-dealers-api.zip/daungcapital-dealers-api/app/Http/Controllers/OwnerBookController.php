<?php

namespace App\Http\Controllers;

use App\Filters\OwnerBookFilter;
use App\Partials\OwnerBookPartial;
use Illuminate\Http\Request;

class OwnerBookController extends Controller
{
    private $ownerBookPartial;
    private $ownerBookFilter;

    public function __construct(OwnerBookPartial $ownerBookPartial, OwnerBookFilter $ownerBookFilter)
    {
        $this->ownerBookPartial = $ownerBookPartial;
        $this->ownerBookFilter = $ownerBookFilter;
    }

    public function index(Request $request)
    {
        return $request->user()
                       ->ownerBooks()
                       ->partial($this->ownerBookPartial)
                       ->filter($this->ownerBookFilter)
                       ->paginate();
    }

    public function show(Request $request, $id)
    {
        return $request->user()
                       ->ownerBooks()
                       ->partial($this->ownerBookPartial)
                       ->findOrFail($id);
    }

    public function meta(Request $request)
    {
        return [];

        return $request->user()
                       ->ownerBooks()
                       ->partial($this->ownerBookPartial)
                       ->findOrFail($id);
    }
}

<?php

namespace App\Http\Controllers;

use App\Filters\CustomerFilter;
use App\Http\Requests\StoreCustomer;
use App\Models\Customer;
use App\Models\TemporaryUpload;
use App\Partials\CustomerPartial;
use App\Services\CustomerMetaService;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    private $customerPartial;
    private $customerFilter;

    public function __construct(CustomerPartial $customerPartial, CustomerFilter $customerFilter)
    {
        $this->customerPartial = $customerPartial;
        $this->customerFilter = $customerFilter;
    }

    public function index(Request $request)
    {
        return $request->user()
                       ->customers()
                       ->partial($this->customerPartial)
                       ->filter($this->customerFilter)
                       ->order()
                       ->paginate();
    }

    public function store(StoreCustomer $request)
    {
        $customer = $request->user()
                            ->customers()
                            ->create($request->validated());

        $this->attachMedia($customer, $request);

        $this->createFingerprint($customer, $request);

        return $customer;
    }

    public function show(Request $request, $id)
    {
        return $request->user()
                       ->customers()
                       ->partial($this->customerPartial)
                       ->where('_id', $id)
                       ->firstOrFail();
    }

    public function delete(Request $request, $id)
    {
        $customer = $request->user()
                            ->customers()
                            ->where('_id', $id)
                            ->firstOrFail();

        if ($customer->loans()->count()) {
            return $this->forbiddenResponse(
                'This customer has one or more active loans thus deleting the resource is disallowed.'
            );
        };

        return $this->deleteResponse($customer->delete());
    }

    public function find(Request $request)
    {
        return Customer::filter($this->customerFilter)
                       ->partial($this->customerPartial)
                       ->firstOrFail();
    }

    public function meta(CustomerMetaService $customerMetaService)
    {
        return [
            'total_count' => request()->user()->customers()->count(),
            'new_count' => $customerMetaService->new()->count(),
            'passive_count' => $customerMetaService->passive()->count(),
            'active_count' => $customerMetaService->active()->count(),
        ];
    }


    private function createFingerprint(Customer $customer, Request $request)
    {
        $fingerprint = $customer->fingerprint()->create($request->fingerprint);

        $temp = (new TemporaryUpload())->find($request->fingerprint['temporary_upload_id']);
        $media = $temp->getMedia()->first();
        $media->move($fingerprint);
        $temp->delete();

        return $fingerprint;
    }

    private function attachMedia(Customer $customer, Request $request)
    {
        $temps = (new TemporaryUpload())->whereIn('id', $request->temporary_upload_ids)->get();

        $temps->map(function ($temp) use ($customer) {
            $temp->getMedia()->map(function ($media) use ($customer) {
                $media->move($customer);
            });
            $temp->delete();
        });
    }

}

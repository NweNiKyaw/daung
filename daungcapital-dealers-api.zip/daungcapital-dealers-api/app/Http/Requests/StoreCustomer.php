<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCustomer extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'phone' => 'required|unique:customers',
            'name' => 'required',
            'nrc_number' => 'required',
            'gender' => 'required|in:Male,Female,male,female',
            'dob' => 'required',
            'fathers_name' => 'required',
            'address' => 'required',
            'years_current_address' => 'required',
            'living_with' => 'required|in:Friends,Parents,Relatives,Spouse,friends,parents,relatives,spouse',
            'residence_type' => 'required|in:Hostel,Owner,Parental,Rent,hostel,owner,parental,rent',
            'marital_status' => 'required|in:Married,Single,married,single',
            'temporary_upload_ids' => 'required|array',
            'temporary_upload_ids.*' => 'exists:temporary_uploads,id|different:fingerprint.temporary_upload_id',
            'fingerprint.ansi' => 'required',
            'fingerprint.iso' => 'required',
            'fingerprint.temporary_upload_id' => 'required|exists:temporary_uploads,id|different:temporary_upload_ids',
        ];
    }
}

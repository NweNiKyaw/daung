<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreLoan extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'borrower_id' => [
                'required',
                'integer',
                Rule::exists('customers', '_id')->where('user_id', request()->user()->getKey())
            ],

            'principal' => 'required|numeric',
            "package" => 'required|in:a,b,c',
            'fingerprint_score' => 'integer|nullable|min:0|max:100',
            'temporary_upload_ids' => 'array',

            'item.brand' => 'required',
            'item.chassis_number' => 'required',
            'item.color' => 'required',
            'item.deposit' => 'required|integer',
            'item.engine_number' => 'required',
            'item.license_number' => 'string|nullable',
            'item.model' => 'required',
            'item.price' => 'required',
            'item.type' => 'required|in:motorcycle,threewheeler',

            'fingerprint.ansi' => 'required_with:fingerprint.iso,fingerprint.temporary_upload_id|string',
            'fingerprint.iso' => 'required_with:fingerprint.ansi,fingerprint.temporary_upload_id|string',
            'fingerprint.temporary_upload_id' => 'required_with:fingerprint.ansi,fingerprint.iso|integer|exists:temporary_uploads,id',
        ];
    }
}

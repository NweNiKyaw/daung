<?php

namespace App\Http\Middleware;

use Closure;
use App\DaungCapital\Helper;

class FormatPhoneNumber
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->filled('phone')) {
            $request->merge(['phone' => Helper::formatPhoneNumber($request->phone)]);
        }

        return $next($request);
    }
}

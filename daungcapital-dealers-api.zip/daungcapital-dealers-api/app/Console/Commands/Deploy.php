<?php

namespace App\Console\Commands;

use File;
use Illuminate\Console\Command;

class Deploy extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deploy {server=production}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Deploy code to server';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if (!File::exists('.env')) {
            $this->error("can't find environment file (.env)");

            return false;
        }

        $environment = (new \josegonzalez\Dotenv\Loader(base_path('.env')))
                      ->parse()
                      ->toArray();

        $deploy_server = $environment['DEPLOY_SERVER'] ?? false;

        if (!$deploy_server) {
            $this->error('DEPLOY_SERVER variable in .env is required');

            return false;
        }

        $this->info("connecting to the deploy server {$deploy_server} ...");
        exec("ssh -p22 \$USER@{$deploy_server} '{$this->deployCommands()}'");
        $this->info('Done');
    }

    private function deployCommands()
    {
        return '
            cd /var/www/html/api
            git pull origin master
            composer install --no-dev --optimize-autoloader
            php artisan config:cache
        ';
    }
}

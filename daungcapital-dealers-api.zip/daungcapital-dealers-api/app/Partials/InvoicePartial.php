<?php

namespace App\Partials;

use App\Contracts\Partial;

class InvoicePartial extends Partial
{
    public function loanPartial()
    {
        $this->builder->with('loan');
    }

    public function loanDotItemPartial()
    {
        $this->builder->with('loan.item');
    }

    public function loanDotContractPartial()
    {
        $this->builder->with('loan.contract');
    }

    public function loanDotBorrowerPartial()
    {
        $this->builder->with('loan.borrower');
    }

    public function paymentsPartial()
    {
        $this->builder->with('payments');
    }
}

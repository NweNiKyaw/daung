<?php

namespace App\Partials;

use App\Contracts\Partial;

class LoanPartial extends Partial
{
    public function borrowerPartial()
    {
        return $this->builder->with('borrower');
    }

    public function contractPartial()
    {
        return $this->builder->with('contract');
    }

    public function itemPartial()
    {
        return $this->builder->with('item');
    }

    public function mediaPartial()
    {
        return $this->builder->with('media');
    }

    public function borrowerDotFingerprintPartial()
    {
        $this->builder->with('borrower.fingerprint');
    }

    public function borrowerDotFingerprintDotMediaPartial()
    {
        $this->builder->with('borrower.fingerprint.media');
    }

    public function fingerprintPartial()
    {
        $this->builder->with('fingerprint');
    }

    public function fingerprintDotMediaPartial()
    {
        $this->builder->with('fingerprint.media');
    }
}

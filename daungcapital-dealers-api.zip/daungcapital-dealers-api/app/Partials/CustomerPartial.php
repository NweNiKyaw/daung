<?php

namespace App\Partials;

use App\Contracts\Partial;

class CustomerPartial extends Partial
{
    public function fingerprintPartial()
    {
        $this->builder->with('fingerprint');
    }

    public function loansPartial()
    {
        $this->builder->with('loans');
    }

    public function mediaPartial()
    {
        $this->builder->with('media');
    }

    public function fingerprintDotMediaPartial()
    {
        $this->builder->with('fingerprint.media');
    }
}

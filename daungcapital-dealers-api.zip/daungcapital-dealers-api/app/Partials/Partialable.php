<?php

namespace App\Partials;

use App\Contracts\Partial;

trait Partialable
{
    public function scopePartial($query, Partial $partial)
    {
        return $partial->apply($query, $this);
    }
}

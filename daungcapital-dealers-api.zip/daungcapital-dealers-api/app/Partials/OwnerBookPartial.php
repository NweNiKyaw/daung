<?php

namespace App\Partials;

use App\Contracts\Partial;

class OwnerBookPartial extends Partial
{
    public function loanPartial()
    {
        $this->builder->with('loan');
    }
}

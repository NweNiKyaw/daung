<?php

namespace App\Partials;

use App\Contracts\Partial;

class PaymentPartial extends Partial
{
}

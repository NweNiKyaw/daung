<?php

namespace App\Services;

use Illuminate\Database\Eloquent\Builder;

class OrderService
{
    private $orderableColumns;

    public function apply(Builder $model, $orderableColumns)
    {
        $request = request();

        if (!$request->filled('orders_by') || !is_array($request->orders_by)) {
            return false;
        }

        $this->orderableColumns = $orderableColumns;

        $ordersBy = $this->filterOutBadColumns($request->orders_by);

        foreach ($ordersBy as $column => $direction) {
            $model->orderBy($column, $direction);
        }
    }

    public function filterOutBadColumns($ordersByData)
    {
        return array_filter($ordersByData, function ($key) {
            return in_array(strval($key), $this->orderableColumns);
        }, ARRAY_FILTER_USE_KEY);
    }
}

<?php

namespace App\Services;

class CustomerMetaService
{
    public function new()
    {
        return request()->user()
                        ->customers()
                        ->where('customers.status', 'new');
    }

    public function passive()
    {
        return request()->user()
                        ->customers()
                        ->where('customers.status', 'passive');
    }

    public function active()
    {
        return request()->user()
                        ->customers()
                        ->where('customers.status', 'active');
    }
}

<?php

namespace App\Scopes;

use App\Models\Invoice;
use App\Models\Payment;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class InvoiceStatusScope implements Scope
{
    public function apply(Builder $builder, Model $model)
    {
        $invoice = new Invoice;
        $payment = new Payment;

        $invoiceTable = $invoice->getTable();
        $paymentTable = $payment->getTable();

        $invoiceKey = $invoice->getKeyName();

        $now = now();
        $builder->selectRaw('paid_sum, is_overdue, total_payments_count')->join(DB::raw(
            "(SELECT
                {$invoiceKey} as invoice_status_id,
                IF(due_date < NOW(), 1, 0) as is_overdue,
                (SELECT COUNT(*) FROM {$paymentTable} WHERE {$invoiceTable}.{$invoiceKey} = {$paymentTable}.invoice_id) as total_payments_count,
                IFNULL((SELECT SUM(amount) FROM {$paymentTable} WHERE {$invoiceTable}.{$invoiceKey} = {$paymentTable}.invoice_id GROUP BY {$paymentTable}.invoice_id),0) as paid_sum
                FROM {$invoiceTable}
            ) as invoice_status"
        ), function ($join) use ($invoiceTable, $invoiceKey) {
            $join->on('invoice_status.invoice_status_id', '=', "{$invoiceTable}.{$invoiceKey}");
        });
    }
}

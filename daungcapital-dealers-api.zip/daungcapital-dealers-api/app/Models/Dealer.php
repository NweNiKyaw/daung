<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class Dealer extends Authenticatable
{
    use HasApiTokens, Notifiable;
    use \Staudenmeir\EloquentHasManyDeep\HasRelationships;

    protected $primaryKey = '_id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function customers()
    {
        return $this->hasMany(Customer::class, 'user_id');
    }

    public function loans()
    {
        return $this->hasManyThrough(Loan::class, Customer::class, 'user_id', 'borrower_id');
    }

    public function invoices()
    {
        return $this->hasManyDeep(
            Invoice::class,
            [Customer::class, Loan::class],
            ['user_id', 'borrower_id']
        );
    }

    public function ownerBooks()
    {
        return $this->hasManyDeep(
            OwnerBook::class,
            [Customer::class, Loan::class],
            ['user_id', 'borrower_id']
        );
    }

    public function contracts()
    {
        return $this->hasManyDeep(
            Contract::class,
            [Customer::class, Loan::class],
            ['user_id', 'borrower_id']
        );
    }

    public function dealerInvoices()
    {
        return $this->hasMany(DealerInvoice::class, 'dealer_id', '_id');
    }

    public function tablets()
    {
        return $this->hasMany(Tablet::class, 'dealer_id');
    }
}

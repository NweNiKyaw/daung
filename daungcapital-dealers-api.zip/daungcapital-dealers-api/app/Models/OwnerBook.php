<?php

namespace App\Models;

use App\Filters\Filterable;
use App\Partials\Partialable;
use Illuminate\Database\Eloquent\Model;

class OwnerBook extends Model
{
    protected $primaryKey = '_id';

    use Partialable, Filterable;

    public function loan()
    {
        return $this->belongsTo(Loan::class);
    }
}

<?php

namespace App\Models;

use App\Filters\Filterable;
use App\Partials\Partialable;
use App\Scopes\InvoiceStatusScope;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Invoice extends Model
{
    use Partialable, Filterable;

    protected $primaryKey = '_id';

    protected $appends = [
        'status'
    ];

    protected static function boot()
    {
        parent::boot();

        static::addGlobalScope('cancelled',function($builder){
            $builder->where('invoices.name','NOT LIKE',"% (cancelled)");
        });
        static::addGlobalScope(new InvoiceStatusScope);
    }

    public function loan()
    {
        return $this->belongsTo(Loan::class);
    }

    public function getStatusAttribute()
    {
        if ($this->total_payments_count > 0 && $this->paid_sum >= $this->amount) {
            return 'paid';
        }

        if ($this->total_payments_count > 0 && $this->paid_sum < $this->amount && !$this->is_overdue) {
            return 'partial';
        }

        if ($this->total_payments_count === 0 && Carbon::parse($this->due_date)->format('Y-m') == Carbon::now()->format('Y-m')) {
            return 'unpaid';
        }

        if ($this->paid_sum < $this->amount && $this->is_overdue) {
            return 'overdue';
        }

        return 'draft';
    }

    public function scopeStatus($query, $value)
    {
        switch ($value) {
            case 'paid':
                $query->paid();
                break;
            case 'partial':
                $query->_partial();
                break;
            case 'unpaid':
                $query->unpaid();
                break;
            case 'overdue':
                $query->overdue();
                break;
        }
    }

    public function scopePaid($query)
    {
        $query->where([
            ['total_payments_count', '>', 0],
            ['paid_sum', '>=', DB::raw('`amount`')],
        ]);
    }

    public function scope_Partial($query)
    {
        $query->where([
            ['total_payments_count', '>', 0],
            ['paid_sum', '<', DB::raw('`amount`')],
            ['is_overdue', '=', 0],
        ]);
    }

    public function scopeUnpaid($query)
    {
        $query->where([
            ['total_payments_count', '=', 0],
        ])
        ->whereMonth('due_date', NOW())
        ->whereYear('due_date', NOW());
    }

    public function scopeOverdue($query)
    {
        $query->where([
            ['is_overdue', '=', 1],
            ['paid_sum', '<', DB::raw('`amount`')],
        ]);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class, 'invoice_id', '_id');
    }
}

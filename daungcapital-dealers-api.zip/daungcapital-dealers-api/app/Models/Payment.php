<?php

namespace App\Models;

use App\Filters\Filterable;
use App\Partials\Partialable;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use Partialable, Filterable;

    protected $table = 'loan_repayments';

    protected $attributes = [
        'repayment_method_id' => 1
    ];

    protected $fillable = [
        'collection_date',
        'amount',
    ];
}

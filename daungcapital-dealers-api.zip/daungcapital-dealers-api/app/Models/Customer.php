<?php

namespace App\Models;

use App\Events\CustomerDeleting;
use App\Filters\Filterable;
use App\Orders\Orderable;
use App\Partials\Partialable;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

class Customer extends Model implements HasMedia
{
    use Partialable, Filterable, Orderable, HasMediaTrait;

    protected $primaryKey = '_id';

    protected $fillable = [
        'phone',
        'name',
        'nrc_number',
        'gender',
        'dob',
        'fathers_name',
        'address',
        'years_current_address',
        'living_with',
        'residence_type',
        'marital_status',
    ];

    public $orderableColumns = [
        '_id',
        'created_at',
        'updated_at'
    ];

    protected $dispatchesEvents = [
        'deleting' => CustomerDeleting::class,
    ];

    public function loans()
    {
        return $this->hasMany(Loan::class, 'borrower_id', '_id');
    }

    public function fingerprint()
    {
        return $this->morphOne(Fingerprint::class, 'fingerprintable');
    }
}

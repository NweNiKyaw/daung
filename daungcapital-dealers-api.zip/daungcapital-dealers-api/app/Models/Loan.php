<?php

namespace App\Models;

use App\Filters\Filterable;
use App\Orders\Orderable;
use App\Partials\Partialable;
use App\Scopes\LoanExcludeScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

class Loan extends Model implements HasMedia
{
    use Partialable, Filterable, Orderable, HasMediaTrait, SoftDeletes;

    protected $fillable = [
        'borrower_id',
        'user_id',
        'principal',
        'interest_rate',
        'loan_duration',
        'fingerprint_score',
        'submitted_at',
        'submitted_by',
        'admin_fee',
    ];

    protected $attributes = [
        'loan_type' => 'motorcycle',
        'status' => 'submitted',
    ];

    public $orderableColumns = [
        'id',
        'created_at',
        'updated_at',
        'submitted_at'
    ];

    protected $dates = [
        'submitted_at',
    ];

    protected static function boot()
    {
        parent::boot();

        static::addGlobalScope(new LoanExcludeScope);
    }

    public function borrower()
    {
        return $this->belongsTo(Customer::class, 'borrower_id');
    }

    public function contract()
    {
        return $this->hasOne(Contract::class);
    }

    public function item()
    {
        return $this->hasOne(Item::class);
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function fingerprint()
    {
        return $this->morphOne(Fingerprint::class, 'fingerprintable');
    }

    // ::FromV1::
    public function getTotalPaymentAttribute()
    {
        // With some interest method and installment method
        // it is unable to determine the total payment.
        // TODO Check for conditions where total payment cannot be determined ahead of time.

        $principal = $this->principal;
        $rate = $this->interest_rate;
        $period = $this->loan_duration;

        return $principal * (1 + (($rate / 100) * $period));
    }

    // ::FromV1::
    public function getMonthlyPaymentAttribute()
    {
        return $this->totalPayment / $this->loan_duration;
    }

    // ::FromV1::
    public function getInterestAttribute()
    {
        return $this->totalPayment - $this->principal;
    }
}

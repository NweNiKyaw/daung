<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    protected $primaryKey = '_id';

    protected $fillable = [
        'brand',
        'chassis_number',
        'color',
        'deposit',
        'engine_number',
        'license_number',
        'model',
        'price',
        'type',
    ];
}

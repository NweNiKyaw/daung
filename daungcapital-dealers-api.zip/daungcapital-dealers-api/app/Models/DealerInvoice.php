<?php

namespace App\Models;

use App\Filters\Filterable;
use Illuminate\Database\Eloquent\Model;

class DealerInvoice extends Model
{
    protected $table = 'devoices';

    protected $primaryKey = '_id';

    use Filterable;
}

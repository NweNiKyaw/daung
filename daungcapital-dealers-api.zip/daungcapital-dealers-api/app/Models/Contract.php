<?php

namespace App\Models;

use Exception;
use GuzzleHttp\Client;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use SignRequest;

class Contract extends Model
{
    protected $primaryKey = '_id';

    protected $fillable = [
        'contract_number',
        'external_id',
        'sent_at',
    ];

    protected $dates = [
        'sent_at',
    ];

    public function loan()
    {
        return $this->belongsTo(Loan::class);
    }

    public function getSignersAttribute()
    {
        $signers = [];

        $signrequest = null;

        try {
            $signrequest = $this->getSignrequest();
        } catch (Exception $x) {
            Log::error('Error retrieving Signrequest: ' . $x->getMessage());
        }

        if ($signrequest) {
            foreach ($signrequest->getSigners() as $signer) {
                $signers[] = [
                    'email' => $signer->getEmail(),
                    'embed_url' => $signer->getEmbedUrl(),
                    'emailed' => $signer->getEmailed(),
                    'in_person' => $signer->getInPerson(),
                    'needs_to_sign' => $signer->getNeedsToSign(),
                    'order' => $signer->getOrder(),
                    'signed' => $signer->getSigned(),
                    'signed_on' => $signer->getSignedOn(),
                ];
            }
        }

        return $signers;
    }

    public function getSignrequest()
    {
        try {
            $document = $this->getDocument();
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }

        $config = SignRequest\Configuration
            ::getDefaultConfiguration()
            ->setApiKey('Authorization', config('signrequest.token'))
            ->setApiKeyPrefix('Authorization', 'Token');

        $apiInstance = new SignRequest\Api\SignrequestsApi(new Client(), $config);

        $uuid = $document->signrequest->uuid;

        $signrequest = null;

        try {
            $signrequest = $apiInstance->signrequestsRead($uuid);
        } catch (Exception $x) {
            Log::error('Error retrieving Signrequest: ' . $x->getMessage());
        }

        return $signrequest;
    }

    public function getDocument()
    {
        $uuid = $this->external_id;

        if (!$uuid) {
            throw new Exception('Document was not found on the server.');
        }

        $client = new Client([
            'base_uri' => 'https://signrequest.com/api/v1/',
        ]);

        try {
            $response = $client->request('get', 'documents/' . $uuid . '/', [
                'headers' => [
                    'Authorization' => 'Token ' . config('signrequest.token'),
                    'Content-Type' => 'application/json'
                ]
            ]);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }

        if ($response->getStatusCode() !== 200) {
            throw new Exception('Document was not found on the server.');
        }

        return json_decode($response->getBody());
        ;
    }
}

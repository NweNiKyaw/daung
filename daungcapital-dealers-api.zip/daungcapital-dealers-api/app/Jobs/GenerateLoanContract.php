<?php

namespace App\Jobs;

use App\Models\Contract;
use App\Models\Loan;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class GenerateLoanContract implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $loan;

    public function __construct(Loan $loan)
    {
        $this->loan = $loan;
    }

    public function handle()
    {
        $this->generateContract();
    }

    public function generateContract()
    {
        $contract = $this->loan->contract()->create([
            'contract_number' => $this->nextContractNumber()
        ]);

        return $contract;
    }

    private function nextContractNumber()
    {
        $last_contract = Contract::where('contract_number', 'like', $this->contractCode() . '%')
                                 ->orderBy('created_at', 'desc')
                                 ->first();

        $current_number = 0;
        $last_contract_number = $this->contractCode() . $current_number;

        if ($last_contract) {
            $last_contract_number = $last_contract->contract_number;
            $current_number = intval(substr($last_contract_number, strlen($this->contractCode())));
        }

        return sprintf('%s%u', $this->contractCode(), $current_number + 1);
    }

    private function contractCode()
    {
        return 'M';
    }
}

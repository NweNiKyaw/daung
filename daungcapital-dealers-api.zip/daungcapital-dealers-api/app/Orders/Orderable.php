<?php

namespace App\Orders;

use App\Services\OrderService;

trait Orderable
{
    public function scopeOrder($query)
    {
        $orderService = new OrderService;
        $orderService->apply($query, $this->orderableColumns);
    }
}

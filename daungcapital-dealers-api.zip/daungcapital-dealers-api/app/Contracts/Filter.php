<?php

namespace App\Contracts;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

abstract class Filter
{
    protected $builder;
    protected $model;
    protected $params;

    public function __construct()
    {
        $this->params = request()->except('partials');
    }

    public function apply(Builder $builder, Model $model)
    {
        $this->builder = $builder;
        $this->model = $model;

        if (!$this->params) {
            return $this->builder;
        }

        $filterMethods = $this->filterMethods(($this->params));

        foreach ($filterMethods as $method => $value) {
            $this->{$method}($value);
        }

        return $this->builder;
    }

    public function filterMethods($params)
    {
        return collect($params)->mapWithKeys(function ($value, $key) {
            return [$this->operatorSyntaxReplace(Str::camel($key)) . 'Filter' => $value];
        })->filter(function ($value, $key) {
            return method_exists($this, $key);
        });
    }

    private function operatorSyntaxReplace($str)
    {
        if (Str::endsWith($str, '!')) {
            return str_replace('!', 'NotEqual', $str);
        }

        return $str;
    }

    public function limitFilter($value)
    {
        $this->builder->limit($value);
        $this->model->setPerPage((int)$value);
    }
}

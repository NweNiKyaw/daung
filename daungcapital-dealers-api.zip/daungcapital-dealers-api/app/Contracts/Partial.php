<?php

namespace App\Contracts;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

abstract class Partial
{
    protected $builder;
    protected $partials;

    public function __construct()
    {
        $this->partials = request()->get('partials');
    }

    public function apply(Builder $builder, Model $model)
    {
        $this->builder = $builder;
        $this->model = $model;

        if (!$this->partials || !is_array($this->partials)) {
            return $this->builder;
        }

        $partialMethods = $this->partialMethods($this->partials);

        foreach ($partialMethods as $partialMethod) {
            $this->{$partialMethod}();
        }

        return $builder;
    }

    private function partialMethods($fields)
    {
        return collect($fields)->map(function ($field) {
            $key = str_replace('.', ' dot ', $field);

            return Str::camel($key) . 'Partial';
        })->filter(function ($method) {
            return method_exists($this, $method);
        });
    }
}

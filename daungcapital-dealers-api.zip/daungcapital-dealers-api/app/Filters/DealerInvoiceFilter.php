<?php

namespace App\Filters;

use App\Contracts\Filter;

class DealerInvoiceFilter extends Filter
{
    public function dueDateMonthFilter($value)
    {
        $this->builder->whereMonth('due_date', $value);
    }

    public function dueDateYearFilter($value)
    {
        $this->builder->whereYear('due_date', $value);
    }

    public function statusFilter($value)
    {
        $this->builder->where('status', $value);
    }
}

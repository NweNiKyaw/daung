<?php

namespace App\Filters;

use App\Contracts\Filter;
use App\DaungCapital\Helper;

class LoanFilter extends Filter
{
    public function keywordFilter($value)
    {
        $this->builder->where(function ($query) use ($value) {
            $query->whereHas('contract', function ($query) use ($value) {
                return $query->where('contract_number', 'LIKE', "%$value%");
            })
            ->orWhereHas('borrower', function ($query) use ($value) {
                return $query->where('phone', 'LIKE', '%' . Helper::formatPhoneNumber($value) . '%')
                             ->orWhere('name', 'LIKE', "%$value%");
            });
        });
    }

    public function statusFilter($values)
    {
        is_array($values) ? $this->builder->whereIn('loans.status', $values) : $this->builder->where('loans.status', $values);
    }

    public function borrowerIdFilter($value)
    {
        $this->builder->where('borrower_id', $value);
    }
}

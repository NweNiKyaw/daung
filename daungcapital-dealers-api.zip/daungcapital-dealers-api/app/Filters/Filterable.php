<?php

namespace App\Filters;

use App\Contracts\Filter;

trait Filterable
{
    public function scopeFilter($query, Filter $filter)
    {
        return $filter->apply($query, $this);
    }
}

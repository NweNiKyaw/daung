<?php

namespace App\Filters;

use App\Contracts\Filter;

class PaymentFilter extends Filter
{
}

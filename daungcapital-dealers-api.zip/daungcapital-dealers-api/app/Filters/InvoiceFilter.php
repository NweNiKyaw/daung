<?php

namespace App\Filters;

use App\Contracts\Filter;
use App\DaungCapital\Helper;

class InvoiceFilter extends Filter
{
    public function keywordFilter($value)
    {
        return $this->builder
                    ->whereHas('loan', function ($query) use ($value) {
                        return $query->whereHas('contract', function ($query) use ($value) {
                            return $query->where('contract_number', 'LIKE', "%$value%");
                        })->orWhereHas('borrower', function ($query) use ($value) {
                            return $query->where('phone', 'LIKE', '%' . Helper::formatPhoneNumber($value) . '%')
                                        ->orWhere('name', 'LIKE', "%$value%");
                        });
                    });
    }

    public function invoiceDateMonthFilter($value)
    {
        $this->builder->whereMonth('invoice_date', $value);
    }

    public function invoiceDateYearFilter($value)
    {
        $this->builder->whereYear('invoice_date', $value);
    }

    public function dueDateMonthFilter($value)
    {
        $this->builder->whereMonth('due_date', $value);
    }

    public function dueDateYearFilter($value)
    {
        $this->builder->whereYear('due_date', $value);
    }

    public function statusFilter($value)
    {
        $this->builder->status($value);
    }

    public function borrowerIdFilter($value)
    {
        $this->builder->whereHas('loan', function ($query) use ($value) {
            return $query->where('borrower_id', $value);
        });
    }
}

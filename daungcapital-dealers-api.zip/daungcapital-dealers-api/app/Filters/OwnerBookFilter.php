<?php

namespace App\Filters;

use App\Contracts\Filter;

class OwnerBookFilter extends Filter
{
    public function receivedAtMonthFilter($value)
    {
        $this->builder->whereMonth('received_at', $value);
    }

    public function receivedAtYearFilter($value)
    {
        $this->builder->whereYear('received_at', $value);
    }

    public function receivedAtNotEqualFilter($value)
    {
        $this->builder->where('received_at', '!=', $value);
    }

    public function loanStatusFilter($value)
    {
        $this->builder->whereHas('loan', function ($query) use ($value) {
            $query->where('loans.status', $value);
        });
    }

    public function statusFilter($value)
    {
        $this->builder->where('owner_books.status', $value);
    }
}

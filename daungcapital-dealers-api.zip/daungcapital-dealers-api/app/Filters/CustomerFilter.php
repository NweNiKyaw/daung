<?php

namespace App\Filters;

use App\Contracts\Filter;
use App\DaungCapital\Helper;

class CustomerFilter extends Filter
{
    public function approvedByFilter($value)
    {
        $this->builder->where('approved_by', $value);
    }

    public function keywordFilter($value)
    {
        $this->builder->where(function ($query) use ($value) {
            $query
            ->orWhere('phone', 'LIKE', '%' . Helper::formatPhoneNumber($value) . '%')
            ->orWhere('name', 'LIKE', '%' . $value . '%')
            ->orWhere('nrc_number', 'LIKE', '%' . $value . '%');
        });
    }

    public function statusFilter($value)
    {
        $this->builder->where('customers.status', $value);
    }

    public function phoneFilter($value)
    {
        $this->builder->where('phone', $value);
    }

    public function userIdFilter($value)
    {
        $this->builder->where('user_id', $value);
    }
}

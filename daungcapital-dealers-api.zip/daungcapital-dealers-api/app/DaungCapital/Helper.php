<?php

namespace App\DaungCapital;

use Illuminate\Support\Carbon;

class Helper
{
    public static function formatPhoneNumber($value)
    {
        if (substr($value, 0, 1) == '0') {
            $value = '95' . substr($value, 1);
        }

        if (substr($value, 0, 1) == '9') {
            // After country code '95', no phone number in Myanmar starts with 95.
            if (substr($value, 1, 1) != '5') {
                $value = '95' . $value;
            }
        }

        return $value;
    }

    public static function firstDayOfMonth($year, $month)
    {
        return Carbon::parse("{$year}-{$month}-1");
    }

    public static function lastDayOfMonth($year, $month)
    {
        return Carbon::parse("{$year}-{$month}-1")->endOfMonth();
    }

    public static function burmeseNumericToEnglish($subject)
    {
        $search = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        $replace = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

        return str_replace($search, $replace, $subject);
    }
}

<?php

namespace App\DaungCapital;

use App\Models\Setting as ModelsSetting;
use ArrayAccess;

class Setting implements ArrayAccess
{
    public function all()
    {
        return ModelsSetting::get()->mapWithKeys(function ($setting) {
            return [$setting->key => $setting->value];
        });
    }

    public function has($key)
    {
        return ModelsSetting::where('key', $key)->first() ? true : false;
    }

    public function __get($name)
    {
        $data = ModelsSetting::where('key', $name)->first();

        return  $data ? $data->value : null;
    }

    public function offsetGet($offset)
    {
        return $this->__get($offset);
    }

    public function offsetExists($offset)
    {
        return $this->has($offset);
    }

    public function offsetSet($offset, $value)
    {
        // do it later
    }

    public function offsetUnset($offset)
    {
        // do it later
    }
}

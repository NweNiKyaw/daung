<?php

namespace App\DaungCapital;

use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class OCR
{
    const TOKEN_KEY = 'huawei_cloud_token';

    public function ocrMyanmarIDCard($photo)
    {
        try {
            $response = $this->fetch(
                [
                    'method' => 'POST',
                    'url' => config('services.huawei_cloud.myanmar_id_ocr_endpoint'),
                    'data' => [
                        'image' => $this->fileToBase64($photo),
                        'convert_unicode' => true
                    ],
                ],
                [
                    'X-Auth-Token' => $this->getToken()
                ]
            );
        } catch (\Exception $e) {
            Log::error("HUAWEI CLOUD OCR: $e");

            return false;
        }

        return $this->transform(json_decode($response->getBody(), 1)['result']);
    }

    private function fetch($params, $headers = [])
    {
        return (new Client([
            'headers' => $headers,
        ]))->request(
            $params['method'],
            $params['url'],
            ['json' => $params['data']]
        );
    }

    private function fileToBase64($photo)
    {
        return base64_encode(Storage::get($photo));
    }

    private function getToken()
    {
        if (Cache::has(self::TOKEN_KEY)) {
            return Cache::get(self::TOKEN_KEY);
        }

        try {
            $response = $this->fetch([
                'method' => 'POST',
                'url' => config('services.huawei_cloud.token_endpoint'),
                'data' => [
                    'auth' => [
                        'identity' => [
                            'methods' => [
                                'password'
                            ],
                            'password' => [
                                'user' => [
                                    'name' => config('services.huawei_cloud.name'),
                                    'password' => config('services.huawei_cloud.password'),
                                    'domain' => [
                                        'name' => config('services.huawei_cloud.domain_name')
                                    ]
                                ]
                            ]
                        ],
                        'scope' => [
                            'project' => [
                                'name' => 'ap-southeast-1'
                            ]
                        ]
                    ]]
            ]);
        } catch (\Exception $e) {
            Log::error("HUAWEI CLOUD TOKEN: $e");
            abort(500, $e->getMessage());
        } finally {
            Cache::put(
                self::TOKEN_KEY,
                $response->getHeader('X-Subject-Token')[0],
                Carbon::parse(json_decode($response->getBody())->token->expires_at)
            );

            return Cache::get(self::TOKEN_KEY);
        }
    }

    private function transform($data)
    {
        $result = [];
        foreach ($data as $key => $value) {
            switch ($key) {
                case 'birth':
                    $result[$key] = Helper::burmeseNumericToEnglish($value);
                    break;
                default:
                    $result[$key] = $value;
                    break;
                }
        }

        return $result;
    }
}

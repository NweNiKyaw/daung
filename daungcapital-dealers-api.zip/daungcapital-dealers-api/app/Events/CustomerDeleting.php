<?php

namespace App\Events;

use App\Models\Customer;
use Illuminate\Queue\SerializesModels;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;

class CustomerDeleting
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(Customer $customer)
    {
        $this->deleteFingerprint($customer);
    }

    private function deleteFingerprint($customer)
    {
        if ($customer->fingerprint()->count()) {
            $customer->fingerprint()->delete();
        }
    }
}

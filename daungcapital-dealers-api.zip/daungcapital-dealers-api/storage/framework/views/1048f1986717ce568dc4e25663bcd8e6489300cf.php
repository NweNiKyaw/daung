<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/3.23.11/swagger-ui.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-themes@3.0.0/themes/3.x/theme-muted.css">
    <script src="//unpkg.com/swagger-ui-dist@3/swagger-ui-bundle.js"></script>
    <title>Documentation - APIs</title>
</head>
<body>
    <div id="swagger-ui"></div>
    <script>
      const ui = SwaggerUIBundle({
        url: "<?php echo $url; ?>",
        dom_id: '#swagger-ui',
        docExpansion:"list",
        supportedSubmitMethods: []
      })
    </script>
</body>
</html>
<?php /**PATH /home/nweni/kozin/daungcapital-dealers-api/resources/views/api_documentation.blade.php ENDPATH**/ ?>
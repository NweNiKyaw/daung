<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ModifyColumnsInTablesForBetterPerformance extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // known error of Doctrine, not support enum type
        // https://stackoverflow.com/questions/33140860/laravel-5-1-unknown-database-type-enum-requested
        DB::statement('ALTER TABLE `borrowers` CHANGE `profileable_type` `profileable_type` VARCHAR(255) NULL;');
        DB::statement('ALTER TABLE `borrowers` CHANGE `profileable_id` `profileable_id` BIGINT(20) UNSIGNED NULL;');
        DB::statement('ALTER TABLE `borrowers` CHANGE `position` `position` VARCHAR(255) NULL;');
        DB::statement('ALTER TABLE `borrowers` CHANGE `business_contact_person_email` `business_contact_person_email` VARCHAR(255) NULL;');

        Schema::table('borrowers', function (Blueprint $table) {
            $table->index('user_id');
        });

        Schema::table('customers', function (Blueprint $table) {
            $table->string('name')->nullable()->change();
            $table->string('password')->nullable()->change();
        });

        Schema::table('fingerprints', function (Blueprint $table) {
            $table->text('iso')->change();
            $table->text('ansi')->change();
        });

        Schema::table('invoices', function (Blueprint $table) {
            $table->index('loan_id');
        });

        Schema::table('loan_repayments', function (Blueprint $table) {
            $table->unsignedInteger('loan_id')->nullable()->change();
            $table->unsignedInteger('user_id')->nullable()->change();
        });

        Schema::table('loans', function (Blueprint $table) {
            $table->index('borrower_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('ALTER TABLE `borrowers` CHANGE `profileable_type` `profileable_type` VARCHAR(255) NOT NULL;');
        DB::statement('ALTER TABLE `borrowers` CHANGE `profileable_id` `profileable_id` BIGINT(20) UNSIGNED NOT NULL;');
        DB::statement('ALTER TABLE `borrowers` CHANGE `position` `position` VARCHAR(255) NOT NULL;');
        DB::statement('ALTER TABLE `borrowers` CHANGE `business_contact_person_email` `business_contact_person_email` VARCHAR(255) NOT NULL;');

        Schema::table('borrowers', function (Blueprint $table) {
            $table->dropIndex('borrowers_user_id_index');
        });

        Schema::table('customers', function (Blueprint $table) {
            $table->string('name')->nullable(false)->change();
            $table->string('password')->nullable(false)->change();
        });

        Schema::table('fingerprints', function (Blueprint $table) {
            $table->string('iso')->change();
            $table->string('ansi')->change();
        });

        Schema::table('invoices', function (Blueprint $table) {
            $table->dropIndex('invoices_loan_id_index');
        });

        Schema::table('loan_repayments', function (Blueprint $table) {
            $table->unsignedInteger('loan_id')->nullable(false)->change();
            $table->unsignedInteger('user_id')->nullable(false)->change();
        });

        Schema::table('loans', function (Blueprint $table) {
            $table->dropIndex('loans_borrower_id_index');
        });
    }
}
